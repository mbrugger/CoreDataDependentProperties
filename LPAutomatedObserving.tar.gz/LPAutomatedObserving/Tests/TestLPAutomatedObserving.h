#import <SenTestingKit/SenTestingKit.h>
#import "ManagedObjectSenTestCase.h"

@interface TestLPAutomatedObserving : ManagedObjectSenTestCase {

	NSInteger observerCount;
}

@end
