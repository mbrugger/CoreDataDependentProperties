#import <Cocoa/Cocoa.h>

@interface LPManagedObject : NSManagedObject {

}


@end
